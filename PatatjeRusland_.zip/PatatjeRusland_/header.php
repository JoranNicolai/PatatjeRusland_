<?php ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<header class="center">
    <a href="index.php"><button class="buttonhome">Home</button></a>
    <a href="menu.php"><button class="buttonhome">Menu</button></a>
    <a href="reserveren.php"><button class="buttonhome">Reserveren</button></a>
    <a href="contact.php"><button class="buttonhome">Contact</button></a>
    <a href="login.php"><button class="buttonhome">Login</button></a>
</header>
</body>
</html>