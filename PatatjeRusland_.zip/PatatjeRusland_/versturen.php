<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="CSS/styles.css">
</head>
<div class="center">
<h1>Bedankt voor uw bestelling!</h1>

</div>
<div class="center1">
<img src="images/Etiket-Sticker-Ø45mm-Bedankt-voor-de-bestelling-wit-goud-0118998.png" width="400px">
</div>

<?php
$sql = ''
?>
<body>

</body>
</html>